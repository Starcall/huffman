//
// Created by Trubeckoj Bogdan on 06.06.2018.
//

#ifndef HAFFMUN_HUFFMAN_TREE_H
#define HAFFMUN_HUFFMAN_TREE_H

#include <cstdio>
#include <utility>
#include <vector>


struct huffman_tree {
    huffman_tree() = default;

    explicit huffman_tree(std::vector<size_t>); // create from frequency

    uint64_t get_code(char);

    std::vector<uint64_t> get_codes();
    std::vector<size_t> get_sizes();

    size_t get_size(char);

    void move_left();
    void move_right();
    bool is_leaf();
    char get_symbol();
    void reset();


    ~huffman_tree() = default;

private:

    std::vector<uint64_t> codes;
    std::vector<size_t> sz;

    struct node {
        node* left_child;
        node* right_child;
        char symbol;
        bool term;
        size_t count;
        node() {
            left_child = right_child = nullptr;
            symbol = 0;
            count = 0;
        }
        node (char symbol, size_t count, node* left_child, node* right_child, bool is_term) {
            this->left_child = left_child;
            this->right_child = right_child;
            this->symbol = symbol;
            this->count = count;
            this->term = is_term;
        }
    };

    node* root;
    node* currentNode;

    struct node_compare {
        bool operator () (const node* a, const node* b) {
            return a->count > b->count;
        }
    };

    void count_codes(node* , uint64_t, size_t);

};

#endif //HAFFMUN_HUFFMAN_TREE_H
