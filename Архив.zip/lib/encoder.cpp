//
// Created by Trubeckoj Bogdan on 09.06.2018.
//

#include <vector>
#include "encoder.h"

std::vector<char> encoder::encode(std::vector<char> text) {
    std::vector<char> ans;
    for (char &c : text) {
        uint64_t curCode = tree.get_code(c);
        uint64_t copyCurCode = curCode;
        for (size_t i = 0; i < tree.get_size(c); i++) {
            char curBit = static_cast<char>(curCode % 2);
            ans.push_back(curBit);
            curCode /= 2;
        }
        std::reverse(ans.rbegin(), ans.rbegin() + tree.get_size(c));
    }
    return ans;
}

std::vector<uint64_t> encoder::get_codes() {
    return tree.get_codes();
}

std::vector<size_t> encoder::get_sizes() {
    return tree.get_sizes();
}
