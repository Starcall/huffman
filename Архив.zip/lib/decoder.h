//
// Created by Trubeckoj Bogdan on 11.06.2018.
//

#ifndef HAFFMUN_DECODER_H
#define HAFFMUN_DECODER_H

#include "huffman_tree.h"

struct decoder {
    //decoder() = delete;
    decoder(std::vector<size_t> frequency) : tree(frequency){
        tree.reset();
    };
    std::vector<char> decode(std::vector<char> text);

private:
    huffman_tree tree;
};



#endif //HAFFMUN_DECODER_H
