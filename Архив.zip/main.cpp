#include <iostream>
#include "lib/huffman_tree.h"
#include "lib/encoder.h"
#include "lib/decoder.h"
#include "util/compressor.h"
#include "util/decompressor.h"
#include <ctime>
int main() {

    compressor c("/Users/starcall/CLionProjects/haffmun/cmake-build-debug/input.txt");
    c.compress("/Users/starcall/CLionProjects/haffmun/cmake-build-debug/output.txt");
    decompressor d("/Users/starcall/CLionProjects/haffmun/cmake-build-debug/output.txt");
    d.decompress("/Users/starcall/CLionProjects/haffmun/cmake-build-debug/out.txt");

    std::cout << std::fixed << 1.0 * std::clock() / CLOCKS_PER_SEC << std::endl;
    return 0;
}
