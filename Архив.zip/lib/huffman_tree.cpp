//
// Created by Trubeckoj Bogdan on 06.06.2018.
//
#include <vector>
#include <queue>
#include <cassert>
#include <iostream>
#include "huffman_tree.h"

huffman_tree::huffman_tree(std::vector<size_t> frequency) {
    codes.resize(256);
    sz.resize(256);
    std::priority_queue<node*, std::vector<node*>, node_compare> data;
    size_t counter = 0;
    for (size_t i = 0; i < frequency.size(); i++) {
        if (frequency[i] != 0) {
            data.emplace(new node(i, frequency[i], nullptr, nullptr, true));
            counter++;
        }
    }
    while (data.size() > 1) {
        node* first_node = data.top();
        data.pop();
        node* second_node = data.top();
        data.pop();
        data.emplace(new node(0, first_node->count + second_node->count, first_node, second_node, false));
    }
    this->root = data.top();
    if (counter > 1) {
        count_codes(this->root, 0, 0);
    } else {
        codes[this->root->symbol] = 0;
        sz[this->root->symbol] = 1;
    }

}

uint64_t huffman_tree::get_code(char symbol) {
    return codes[symbol];
}

void huffman_tree::count_codes(huffman_tree::node *cur_node, uint64_t cur_code, size_t depth) {
    if (cur_node == nullptr)
        return;
    count_codes(cur_node->left_child, cur_code * 2, depth + 1);
    if (cur_node->term) {
        codes[cur_node->symbol] = cur_code;
        sz[cur_node->symbol] = depth;
    }
    count_codes(cur_node->right_child, cur_code * 2 + 1, depth + 1);
}

std::vector<uint64_t> huffman_tree::get_codes() {
    return codes;
}

void huffman_tree::move_left() {
    //assert(!is_leaf());
    if (!is_leaf())
     currentNode = currentNode->left_child;

}

void huffman_tree::move_right() {
    //assert(!is_leaf());
    if (!is_leaf())
        currentNode = currentNode->right_child;

}

bool huffman_tree::is_leaf() {
    return currentNode->term;
}

void huffman_tree::reset() {
    currentNode = root;
}

char huffman_tree::get_symbol() {
   // assert(is_leaf());
    return currentNode->symbol;
}

size_t huffman_tree::get_size(char symbol) {
    return sz[symbol];
}

std::vector<size_t> huffman_tree::get_sizes() {

    return sz;
}



