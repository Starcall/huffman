//
// Created by Trubeckoj Bogdan on 14.06.2018.
//

#include <vector>
#include "decoder.h"

std::vector<char> decoder::decode(std::vector<char> text) {
    size_t pos = 0;
    std::vector<char> ans;
    std::vector<char> realText;
    for (size_t i = 0; i < text.size(); i++) {
        for (int j = 7; j >= 0; j--) {
            if ((text[i] & (1 << j)) != 0) {
                realText.push_back(1);
            } else {
                realText.push_back(0);
            }
        }
    }
    for (size_t i = 0; i < realText.size(); i++){
        if (tree.is_leaf()) {
            ans.push_back(tree.get_symbol());
            tree.reset();
            //pos++;
        }
        if (realText[i] == 1) {
            tree.move_right();
        } else {
            tree.move_left();
        }

    }
    return ans;
}
